//
//  FaceHubDelegate.h
//  FaceHub
//
//  Created by Satoru on 2015/12/16.
//  Copyright © 2015年 Satoru Furuta. All rights reserved.
//

@protocol FaceHubDelegate
@optional
-(void)faceHubViewDidDisappear;
@end

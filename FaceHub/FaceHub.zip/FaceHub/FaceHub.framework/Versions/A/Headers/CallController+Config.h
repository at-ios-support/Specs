//
//  CallController+Config.h
//  FaceHub
//
//  Created by satoru on 2015/11/04.
//  Copyright (c) 2015年 Satoru Furuta. All rights reserved.
//

#import "CallController.h"

@interface CallController (Config)
- (void)setConfig:(NSDictionary *)config;
@end

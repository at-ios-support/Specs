//
//  FaceHub.h
//  FaceHub
//
//  Created by satoru on 2015/10/31.
//  Copyright (c) 2015年 Satoru Furuta. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol FaceHubDelegate;
@class UIAlertController;

@interface FaceHub : NSObject
+ (id)getViewWithConfig:(NSDictionary *)config delegate:(id<FaceHubDelegate>)delegate;
+ (void)onLaunchAppWithURL:(NSURL *)url delegate:(id<FaceHubDelegate>)delegate __deprecated_msg("use [FaceHub onLaunchAppWithURL: defaultParams: delegate:]");
+ (void)onLaunchAppWithURL:(NSURL *)url options:(NSDictionary *)options delegate:(id<FaceHubDelegate>)delegate __deprecated_msg("use [FaceHub onLaunchAppWithURL: defaultParams: delegate:]");
+ (void)onLaunchAppWithURL:(NSURL *)url defaultParams:(NSDictionary *)defaultParams delegate:(id<FaceHubDelegate>)delegate;
+ (void)onLaunchAppWithUniversalLinks:(NSURL *)url defaultParams:(NSDictionary *)defaultParams delegate:(id<FaceHubDelegate>)delegate;
+ (NSString *)serviceServer:(NSString *)host;
+ (void)applicationDidEnterBackground;
+ (void)applicationDidBecomeActive;
+ (NSString *)clientVersion;
+ (void)showAlert:(UIAlertController *)alertController;
@end
